package com.example.myproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;

import java.io.File;

public class ThirdActivity extends AppCompatActivity {

    //initialisation
    MediaRecorder mediaRecorder;
    int i = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        //on demande a l'utilisateur d'accordé ses 2 permissions
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        }, PackageManager.PERMISSION_GRANTED);

        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.RECORD_AUDIO
        }, PackageManager.PERMISSION_GRANTED);

        mediaRecorder = new MediaRecorder();
    }

    //action du bouton play
    public void play(View view){
                onplay();
    }

    //action du bouton stop
    public void stop(View view){
                onstop();
    }

    //action du bouton revenir a la page précédente
    public void precedant(View view){
        Intent i = new Intent(this, SecondActivity.class);
        startActivity(i);
    }


    //Fonction qui active l'enregistrement audio
    private void onplay(){
        try {
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.DEFAULT);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);

            //création d'un fichier contenant l'enregistrement
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File file = new File(path, "/"+i+".3gp");

            mediaRecorder.setOutputFile(file);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

            mediaRecorder.prepare();
            mediaRecorder.start();
            Toast.makeText(this, "enregistrement lancé ", Toast.LENGTH_LONG).show();
        } catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this, "echec de l'enregistrement", Toast.LENGTH_LONG).show();
        }
    }

    //ffonction qui stop et qui enregistre le fichier dans notre téléphone
    private  void onstop(){
        try {
            mediaRecorder.stop();
            mediaRecorder.release();
            Toast.makeText(this, "enregistrement "+i, Toast.LENGTH_LONG).show();
            i = i+1;
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "echec de l'enregistrement", Toast.LENGTH_LONG).show();
        }
    }

}