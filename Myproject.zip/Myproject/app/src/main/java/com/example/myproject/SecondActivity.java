package com.example.myproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;


public class SecondActivity extends AppCompatActivity implements LocationListener {

    //initialisation
    TextView textView_position;
    LocationManager locationManager;
    String phoneNumber = "17";
    TextView nom;



    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textView_position = findViewById(R.id.textView_pos);

        //récupération et affichage du prenom de l'utilisateur
        nom = findViewById(R.id.name);

        Bundle extras = getIntent().getExtras();
        String n = extras.getString("nom");

        nom.setText(n);

    }

    //Action du bouton "ou vous trouvez vous ?"
    public void position(View view) {

        //on vérifier la permission
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            // si la permission est déja donnée on effectue la fonction getlocation
            getlocation();

        } else {

            // sinon si elle n'est pas donne on l'a demande a l'utilisateur
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    0);

        }

    }

    //fonction qui détermine la position de l'utilisateur
   @SuppressLint( "MissingPermission")
    private void getlocation() {
        try{
            locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
            locationManager.requestLocationUpdates(locationManager.GPS_PROVIDER, 5000, 5, SecondActivity.this);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    //fonction qui détermine la position de l'utilisateur
    public void onLocationChanged(Location location){
        Toast.makeText(this, ""+location.getLatitude()+","+location.getLongitude(), Toast.LENGTH_SHORT).show();
        try{
            Geocoder geocoder = new Geocoder(SecondActivity.this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            String address = addresses.get(0).getAddressLine(0);
            textView_position.setText(address);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void onStatuschanged (String provider, int status, Bundle extras){

    }

    public void onProviderEnabled (String provider){

    }

    public void onProviderDisable(String provider){
        
    }

    //Action du bouton "sms"
    public void smsMessage(View view) {

        // on vérifie que la permission a été donné
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {

            // si elle a été donnée on effectue la fonction Mymessage
            MyMessage();

        } else {

            // sinon on demande la permission a l'utilisteur
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    1);

        }

    }

    //Action du bouton "appel"
    public void appel(View view) {

        //on vérifier la permission
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {

            // si la permission est déja donnée on effectue la fonction Myappel
            Myappel();

        } else {

            //sinon si elle n'est pas donne on l'a demande a l'utilisateur
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CALL_PHONE},
                    10);

        }

    }

    //fontion sui passe a la troisième activité
    public void next(View view){
        Intent i = new Intent(this, ThirdActivity.class);
        startActivity(i);
    }

    // fonction qui permet d'envoyer un message depuis notre application avec smsManager
    private void MyMessage(){
        String Message = "s'il vous plait vennez au "+textView_position.getText();

        try {

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, Message, null, null);

            Toast.makeText(this, "message envoyer au "+phoneNumber+": "+Message, Toast.LENGTH_LONG).show();

        } catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this, "echec de l'envoie"+Message, Toast.LENGTH_LONG).show();
        }
    }

    // fonction qui permet de passer depuis notre application avec l'instence callIntent
    private void Myappel() {
        try {
            // Set the data
            String uri = "numéro:" + phoneNumber;
            Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse(uri));

            if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            startActivity(callIntent);
        } catch(Exception e) {
            Toast.makeText(getApplicationContext(),"echec de l'appel",
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode){
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    MyMessage();
                } else {
                    Toast.makeText(this, "vous n'avais pas la permission requise pour effectuer cette action", Toast.LENGTH_SHORT).show();
                }

                return;
            }

            case 0: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getlocation();
                } else {
                    Toast.makeText(this, "vous n'avais pas la permission requise pour effectuer cette action", Toast.LENGTH_SHORT).show();
                }

                return;
            }

            case 10: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Myappel();
                } else {
                    Toast.makeText(this, "vous n'avais pas la permission requise pour effectuer cette action", Toast.LENGTH_SHORT).show();
                }

                return;
            }

        }
    }

}