package com.example.myproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;


public class SecondActivity extends AppCompatActivity implements LocationListener {
    
    Button button_position;
    TextView textView_position;
    LocationManager locationManager;
    Button button_message;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        
        textView_position = findViewById(R.id.textView_pos);
        button_position = findViewById(R.id.button_pos);
        button_message = findViewById(R.id.Button_message);
        
        /*if(ContextCompat.checkSelfPermission(SecondActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(SecondActivity.this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION
            },100);
        }*/
        
        button_position.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                if(checkCallingOrSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                    getlocation();
                } else {
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION
                    }, 1);
                }
                }
            }
        });

        button_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    if(checkCallingOrSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED){
                        MyMessage();
                    } else {
                        requestPermissions(new String[]{
                                Manifest.permission.SEND_SMS
                        }, 1);
                    }
                }
            }
        });
    }

   @SuppressLint( "MissingPermission")
    private void getlocation() {
        try{
            locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
            locationManager.requestLocationUpdates(locationManager.GPS_PROVIDER, 5000, 5, SecondActivity.this);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void onLocationChanged(Location location){
        Toast.makeText(this, ""+location.getLatitude()+","+location.getLongitude(), Toast.LENGTH_SHORT).show();
        try{
            Geocoder geocoder = new Geocoder(SecondActivity.this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            String address = addresses.get(0).getAddressLine(0);
            textView_position.setText(address);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void onStatuschanged (String provider, int status, Bundle extras){

    }

    public void onProviderEnabled (String provider){

    }

    public void onProviderDisable(String provider){
        
    }

    /*public void btn_envoie (View view){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED){
            MyMessage();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.SEND_SMS
            }, 0);
        }
    }*/

    private void MyMessage(){
        String phoneNumber = "17";
        String Message = "au secour venez au "+textView_position;

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, Message, null, null);

            Toast.makeText(this, "message envoyer", Toast.LENGTH_SHORT).show();

        } catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this, "echec de l'envoie", Toast.LENGTH_SHORT).show();
        }
    }

   /* @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode){
            case 0:
                if(grantResults.length >= 0 && grantResults[0]== PackageManager.PERMISSION_GRANTED){
                    MyMessage();
                } else {
                    Toast.makeText(this, "vous n'avais pas la permission requise pour effectuer cette action", Toast.LENGTH_SHORT).show();
                }

                break;

        }
    }*/
}